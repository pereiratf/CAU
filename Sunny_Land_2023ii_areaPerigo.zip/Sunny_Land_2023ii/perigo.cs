using Godot;
using System;

public partial class perigo : Area2D
{
	[Export] private float x,y;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Scale = new Vector2(x, y);
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
}
