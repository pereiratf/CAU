using Godot;
using System;

public partial class Raposa : CharacterBody2D
{private AnimatedSprite2D animar; //variável de animação
	[Export]private float velocidade=300f; //velocidade de deslocamento
	[Export]private float pulo=-400f; //força do pulo
	[Export]private float gravidade=100f; //força da gravidade
	private Vector2 movimento; //guarda a direção x/y desejada

	//double tempo =0;
    public override void _Ready()
    {
        animar = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
    }

	public void Animacao () {
		if (IsOnFloor()) { //está no chão
			if (movimento.X > 0) {
				animar.Play("correndo");
			} else if (movimento.X < 0) {
					animar.Play("correndo");
			} else {
				animar.Play("parado");
			}
		} else { //não está no chão
			if (movimento.Y < 0) {
				animar.Play("pulando");
			} else {
				animar.Play("caindo");
			}
		}
		if (movimento.X > 0) { //rotaciona o o sprite para olhar na direção certa
			animar.FlipH = false;
		} else if (movimento.X < 0) {
			animar.FlipH = true;

		}
	}
	
    public override void _PhysicsProcess(double delta)
	{
		movimento = Velocity;

		// gravidade
		if (IsOnFloor() == false) {
			movimento.Y += gravidade;
		}
		//IsOnFloor() é true se está no chão
		//IsOnWall() é true se está na parede
		//IsOnCeilling() é true se está no teto
			
		//movimento direita esquerda
		if (Input.IsActionPressed("direita")) {
			movimento.X = velocidade;
		} else if (Input.IsActionPressed("esquerda")) {
			movimento.X = -velocidade;
		} else {
			movimento.X = 0;
		}
		
		// pular
		if (Input.IsActionJustPressed("pular") && IsOnFloor()) {
			movimento.Y = pulo;
		}
					
		Velocity = movimento;
		MoveAndSlide();
		Animacao();
	}
}
