using Godot;
using System;

public partial class Jogador : CharacterBody2D
{
	private AnimatedSprite2D animar; //variável de animação
	[Export]private float velocidade=100f; //velocidade de deslocamento
	private Vector2 movimento; //guarda a direção x/y desejada

	//double tempo =0;
    public override void _Ready()
    {
        animar = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
    }

	public void Animacao () {
		
	}
	
    public override void _PhysicsProcess(double delta)
	{
		movimento = new Vector2(0,0);
		
		//movimento direita esquerda cima baixo
		if (Input.IsActionPressed("direita")) {
			movimento.X = velocidade;
		} 
		if (Input.IsActionPressed("esquerda")) {
			movimento.X = -velocidade;
		}
		if (Input.IsActionPressed("cima")) {
			movimento.Y = -velocidade;
		} 
		if (Input.IsActionPressed("baixo")) {
			movimento.Y = velocidade;
		} 
		
		
		
					
		Velocity = movimento;
		MoveAndSlide();
		Animacao();
	}
}
