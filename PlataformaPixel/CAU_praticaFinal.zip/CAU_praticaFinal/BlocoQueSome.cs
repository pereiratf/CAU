using Godot;
using System;

public partial class BlocoQueSome : Area2D {
	private Timer tempo;
	private bool pisou=false;
	public override void _Ready() {
		//tempo recebe o nó Timer
		tempo = GetNode<Timer>("Timer");
	}
	public override void _Process(double delta) {
		if (tempo.TimeLeft < 0.1f && pisou) {
			//Remove o bloco do jogo
			QueueFree();
		}
		
	}

	public void PisouNoBloco(Node2D body) {
		if (body is Jogador) {
			//Inicia uma Contagem Regressiva de 5 segundos
			//E indica que já pisou
			tempo.Start(5); 
			pisou=true;
		}
	}
}
