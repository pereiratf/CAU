using Godot;
using System;

public partial class mapa_1 : Node2D
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		GetTree().CallGroup("GrupoJogador", "LimiteDeQueda", 400);
		GetTree().CallGroup("GrupoJogador", "DefinePontoInicial", new Vector2(5, 68));
		GetTree().CallGroup("GrupoJogador", "DefineDiamantes", 3);
		GetTree().CallGroup("GrupoJogador", "DefineVida", 3);
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
}
