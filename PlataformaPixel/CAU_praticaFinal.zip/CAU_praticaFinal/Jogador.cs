using Godot;
using System;

public partial class Jogador : CharacterBody2D
{
	private static int limiteDeQueda;
	private int diamante;
	private int vida;
	private Vector2 pontoDeSalvamento;
	private bool isOnWater = false;
	private AnimatedSprite2D animation;
	public const float Speed = 300.0f;
	public const float JumpVelocity = -400.0f;

	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();


	public override void _Ready() {
		animation = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		GlobalPosition = pontoDeSalvamento;
		GD.Print(GlobalPosition.X, " ", GlobalPosition.Y);
	}
	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;

		if (isOnWater){
			velocity = WaterMove(velocity, delta);
 		} else {
			velocity = NormalMove(velocity, delta);
		}
		
		Velocity = velocity;

		PlayerAnimations(velocity);
		if (GlobalPosition.Y > limiteDeQueda){
			
			RetornaAoPontoDeSalvamento();
		}


		MoveAndSlide();
	}

	public Vector2 WaterMove(Vector2 velocity, double delta){
		// Add the gravity.
		velocity.Y += gravity * (float)delta * 0.5f;
	
		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		Vector2 direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		if (direction != Vector2.Zero)
		{
			velocity.X = direction.X * Speed * 0.5f;
		}
		else
		{
			velocity.X = 0;
		}

		if (direction != Vector2.Zero)
		{
			velocity.Y = direction.Y * Speed * 0.5f;
		}
		else
		{
			velocity.Y += 0;
		}
		

		return velocity;

	}


	public Vector2 NormalMove(Vector2 velocity, double delta){
		// Add the gravity.
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		// Handle Jump.
		if (Input.IsActionJustPressed("ui_accept") && IsOnFloor())
			velocity.Y = JumpVelocity;

		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		Vector2 direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		if (direction != Vector2.Zero)
		{
			velocity.X = direction.X * Speed;
		}
		else
		{
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
		}

		return velocity;

	}
	public void PlayerAnimations(Vector2 velocity){
		if (velocity.X != 0) {
				animation.Play("correndo");
				if(velocity.X > 0) {
					animation.FlipH = true;
				} else {
					animation.FlipH = false;
				}
			} else {
				animation.Play("parado");
			}
		if (!IsOnFloor()){
			animation.Play("pulando");
		} 
	}
	public void RetornaAoPontoDeSalvamento() {
		GlobalPosition = pontoDeSalvamento;
		GD.Print("Retornou ao ponto de salamento");
	}

	public void UpdateSavePoint() {
		pontoDeSalvamento = GlobalPosition;
		GD.Print("Ponto Salvo");
	}

	public void WaterTerrain(bool terrain) {
		isOnWater = terrain;
	}

	public void DefinePontoInicial(Vector2 position) {
		pontoDeSalvamento = position;
	}
	public void LimiteDeQueda(int value) {
		limiteDeQueda = value;
		GD.Print(limiteDeQueda);
	}


	public void DefineVida(int value) {
		vida = value;
	}
	public void DefineDiamantes(int value) {
		diamante = value;
	}
	public int GetNumberOfDiamonds() {
		return diamante;
	}



	public void Espetado() {
		GlobalPosition = pontoDeSalvamento;
		vida = vida - 1;
		GD.Print("Retornou ao ponto salvo");
	}

}
