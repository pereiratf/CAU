using Godot;
using System;

public partial class Raposa : CharacterBody2D
{
	private Vector2 direcao;
	[Export]private float velocidade = 400;
	public void controle () {
		if (Input.IsActionPressed ("esquerda")) {
			direcao.X = -1;
		}
		if (Input.IsActionPressed ("direita")) {
			direcao.X = 1;
		}
		
	} //controle()

    public override void _PhysicsProcess(double delta) {
        controle();
		Velocity = direcao * velocidade * (float)delta;
		MoveAndSlide();
		GD.Print(Position.X);
    }
}
