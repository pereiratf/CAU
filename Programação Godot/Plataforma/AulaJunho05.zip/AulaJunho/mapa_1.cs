using Godot;
using System;

public partial class mapa_1 : Node2D {
	private TileMap mapa;

	public override void _Ready() {
		mapa = GetNode<TileMap>("TileMap");
		mapa.EraseCell(0, new Vector2I(25,8));
		mapa.SetCell(0, new Vector2I(25,8), 0, new Vector2I(11,0));
	}

	
	public override void _Process(double delta) {
	}


}
