using Godot;
using System;

public partial class Jogador : CharacterBody2D {
	private Vector2 direcao;
	[Export] private float velocidade = 150;
	[Export] private float gravidade = 100;
	[Export] private float altura_pulo = -5;
	private bool pulo_duplo;
	

	public override void _PhysicsProcess(double delta) 	{
		//Direcao	
		if (Input.IsActionPressed("direita")) {
			direcao.X = 1;
		}else if (Input.IsActionPressed("esquerda")) {
			direcao.X = -1;
		} else {
			direcao.X=0;
		}
		if (IsOnFloor() == false) {
			direcao.Y = direcao.Y + 0.25f;
		} 
		//Pulo normal
		if (Input.IsActionJustPressed("pula") && IsOnFloor()) {
			direcao.Y = altura_pulo;
		}
		//Pulo duplo
		if (Input.IsActionJustPressed("pula") && IsOnFloor() == false && pulo_duplo == true) {
			direcao.Y = altura_pulo;
			pulo_duplo = false;
		}
		//Recarregar pulo duplo
		if (IsOnFloor() == true) {
			pulo_duplo = true;
		}

		if (Input.IsActionJustPressed("acao")) {
			
		}

		//MOVIMENTO
		Velocity = new Vector2(direcao.X * velocidade, direcao.Y * gravidade);
		
		MoveAndSlide();
	}
}
