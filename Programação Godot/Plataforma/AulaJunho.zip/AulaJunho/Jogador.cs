using Godot;
using System;

public partial class Jogador : CharacterBody2D {
	private Vector2 direcao;
	[Export] private float velocidade = 20;
	[Export] private float altura_pulo = -20;
	

	public override void _PhysicsProcess(double delta) 	{
		//Direcao
		
		if (Input.IsActionPressed("direita")) {
			direcao.X = 1;
		}else if (Input.IsActionPressed("esquerda")) {
			direcao.X = -1;
		} else {
			direcao.X=0;
		}
		if (IsOnFloor() == false) {
			direcao.Y = direcao.Y + 0.25f;
		} 
		
		//Pular
		if (Input.IsActionJustPressed("pula") ) {
			direcao.Y = altura_pulo;
		}
		
		Velocity = direcao * velocidade;
		
		MoveAndSlide();
	}
}
