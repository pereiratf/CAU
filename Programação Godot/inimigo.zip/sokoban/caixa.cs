using Godot;
using System;

public partial class caixa : Area2D
{
	private RayCast2D ray;
	private int area_quadrado = 64;
	private Vector2 direcao;
	public override void _Ready() {
		ray = GetNode<RayCast2D>("RayCast2D");
	}
	
	public bool Empurrar(Vector2 direcao, int area_quadrado) {
		ray.TargetPosition = direcao * area_quadrado;
		ray.ForceRaycastUpdate();
		if (!ray.IsColliding()) {
		Position += direcao * area_quadrado;
		return true;
		}
	return false;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
}
