using Godot;
using System;

public partial class jogador : Area2D
{
	private int area_quadrado = 64;
	private Vector2 direcao;
	private Vector2 destino_caixa;
	private RayCast2D ray;
	public override void _Ready()
	{
	}

void movimento() {
		if (Input.IsActionJustPressed("cima")) {
			direcao = new Vector2(0,-1);
		}
		
		if (Input.IsActionJustPressed("baixo")) {
			direcao = new Vector2(0,1);
		}
		
		if (Input.IsActionJustPressed("direita")) {
			direcao = new Vector2(1,0);
		}
		
		if (Input.IsActionJustPressed("esquerda")) {
			direcao = new Vector2(-1,0);
		}
	
		ray = GetNode<RayCast2D>("RayCast2D");
		ray.TargetPosition = direcao * area_quadrado;
		ray.ForceRaycastUpdate();
		
		if (!ray.IsColliding()) {
			Position += direcao * area_quadrado;
		} else {
			if (ray.GetCollider() is Area2D) { 
				Area2D colisor = ray.GetCollider() as Area2D;
				if ( (bool)colisor.Call("Empurrar",direcao,area_quadrado) ) {
					Position += direcao * area_quadrado;
					
					
				}
			}
		}
		}
		
	
public override void _UnhandledInput(InputEvent @event)
{
	if (@event is InputEventKey eventKey)
		if (eventKey.Pressed)
			movimento();
}
}


