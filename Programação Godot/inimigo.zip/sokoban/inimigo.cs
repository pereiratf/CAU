using Godot;
using System;

public partial class inimigo : Area2D
{
	private int area_quadrado = 64;
	private Vector2 direcao;
	private Random r = new Random();
	private int d;

	public void TempoDeAcao() {
		d = r.Next()%4;
		GD.Print(d);
		Movimento();
	}
	void Movimento() {
		if (d==0) {
			direcao = new Vector2(0,-1);
		}
		else if (d==1) {
			direcao = new Vector2(0,1);
		} else if (d==2) {
			direcao = new Vector2(1,0);
		} else {
			direcao = new Vector2(-1,0);
		}
		Position += direcao * area_quadrado;
	}
}
