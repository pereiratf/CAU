using Godot;
using System;

public partial class mapa_2 : Node2D
{
	private Sprite2D objetivo;
	private Area2D caixa;
	public override void _Ready()
	{
		objetivo = GetNode<Sprite2D>("Objetivo");
		caixa = GetNode<Area2D>("Caixa");
	}
	
	public override void _Process(double delta)
	{
		if (objetivo.Position == caixa.Position) {
			GD.Print("Venceu");
			GetTree().ChangeSceneToFile("res://vitória.tscn");
		}
	}
}
