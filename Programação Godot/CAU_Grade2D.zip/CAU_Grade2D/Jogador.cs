using Godot;
using System;

public partial class Jogador : Area2D
{
	private int area_quadrado = 64;
	private Vector2 direcao;
	private RayCast2D ray;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		ray = GetNode<RayCast2D>("RayCast2D");
		
	}

	void Movimento() {
		//Teste de direção
		direcao = new Vector2(0,0);
		if (Input.IsActionPressed("cima")) {
			direcao = new Vector2(0,-1);
		}
		if (Input.IsActionPressed("baixo")) {
			direcao = new Vector2(0,1);
		}
		if (Input.IsActionPressed("esquerda")) {
			direcao = new Vector2(-1,0);
		}
		if (Input.IsActionPressed("direita")) {
			direcao = new Vector2(1,0);
		}
		
		//Fazer o RayCast2D apontar
		ray.TargetPosition = direcao * area_quadrado;
		ray.ForceRaycastUpdate();
		//Ajuste de posição se não estiver colidindo
		if(!ray.IsColliding()) {
			Position += direcao * area_quadrado;
		} else { //ray.IsColliding()
			if(ray.GetCollider() is Area2D) {
				Area2D colisor = (Area2D)ray.GetCollider();
				if ( (bool)colisor.Call("Empurrar", direcao, area_quadrado) ) {
					Position += direcao * area_quadrado;
				}
				
				GD.Print("Area2D bloqueando o caminho");
			}
		}
			
	}
	
	public override void _UnhandledInput(InputEvent @event){
		if (@event is InputEventKey eventKey) {
			if(eventKey.Pressed) {
				Movimento();
			}
		}
	}

}
